<?php
  $servidor="localhost";
  $usuario="root";
  $clave="";
  $baseDeDatos="formulario";

  $enlace = mysqli_connect($servidor, $usuario, $clave, $baseDeDatos);

  if(!$enlace){
    echo"Error en la conexion con el servidor";
  }
?>
<html>
  <head>
    <meta  charset=utf-8" />
    <title>Gestión Escolar-Ingresar</title>
    <style>
    .container {
    display: grid;
    grid-template-columns: 2fr 2fr;
    grid-gap: 20px;
    }
    header,
    footer{
    color: white;
    border-radius: 20px;
    padding: 30px;
    background-color:#373232;
    }
    aside {
    border-right: 1px solid #999;
    }
    </style>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  </head>
  <body background="img/fondo.jpg">
    <nav class="navbar navbar-dark bg-dark">
      <ul class="nav nav-pills nav-fill mr-auto">
        <li class="nav-item">
          <a class="nav-link " href="index.html">Pagina Principal</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Base de datos
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="Ingresardatos.php">Ingresar</a>
            <a class="dropdown-item" href="Verdatos.php">Modificar</a>
            <a class="dropdown-item" href="Consulta.php">Consulta</a>
          </div>
        </li>
        
        <li class="nav-item">
          <a class="nav-link " href="Contacto.html">Contacto</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="Informacion.html">Información</a>
        </li>
      </ul>
    </nav>
    <p align="center">
      <h1 align="center"><font color="black">FORMULARIO DE REGISTRO</font></h1>
      <br>
      <form action=""  class="formulario" id="formulario" name="formulario" method="POST">
        <table width="100%" align="center" border="#373232" bordercolor="white" bgcolor="gray">
          
          <tr>
            <td><label for="input_nombres"><font font size=5>Nombres</font></label></td>
            <td><input required id="input_nombres" type="text" name="Nombres" value="" placeholder="Nombres" /></td>
          </tr>
          <tr>
            <td><label for="primer_apll"><font  font size=5>Primer apellido</font></label></td>
            <td><input required id="primer_apll" type="text" name="Primerapellido" value="" placeholder="Primer apellido" /></td>
          </tr>
          <tr>
            <td><label for="segundo_apll"><font  font size=5>Segundo apellido</font></label></td>
            <td><input required id="segundo_apll" type="text" name="Segundoapellido" value="" placeholder="Segundo apellido" /></td>
          </tr>
          <tr>
            <td><label for="direccion"><font  font size=5>Dirección</font></label></td>
            <td><input required id="direccion" type="text" name="Direccion" value="" placeholder="Direccion" /></td>
          </tr>
          <tr>
            <td><label for="correo"><font  font size=5>Correo electrónico</font></label></td>
            <td><input required id="correo" type="email" name="CorreoElectronico" value="" placeholder="Correo Electronico" /></td>
          </tr>
          <tr>
            <td><label for="telefono"><font  font size=5>Teléfono</font></label></td>
            <td><input required id="telefono" type="tel" name="Telefono" value="" placeholder="Telefono" /></td>
          </tr>
          <tr>
            <td><label for="input_Genero"><font font size=5>Género</font></label></td>
            <td>
              <div class="Genero">
                <select required name="Genero">
                  <option value="">Seleccione</option>
                  <option value="Hombre">Hombre</option>
                  <option value="Mujer">Mujer</option>
                </select>
              </div>
            </td>
          </tr>
        </table>
        <div class="terminos" align="center">
          <input  required type="checkbox" name="terminos" id="terminos">
          <label for="terminos">Acepto Terminos y Condiciones</label>
        </div>
        <br>
        <input type="reset" name="reset" value="Limpiar" />
        <input  type="submit" name="registrarse" value="Registrate">
      </form>


  </div>
    </body>
  </html>
  <?php
  $consulta = "SELECT * FROM datos";
  $ejecutarConsulta = mysqli_query($enlace, $consulta);
  $aux= mysqli_num_rows($ejecutarConsulta);
    if(isset($_POST['registrarse'])){
      $Nombres = $_POST["Nombres"];
      $Primerapellido = $_POST["Primerapellido"];
      $Segundoapellido = $_POST["Segundoapellido"];
      $Genero = $_POST["Genero"];
      $Direccion = $_POST["Direccion"];
      $CorreoElectronico = $_POST["CorreoElectronico"];
      $Telefono = $_POST["Telefono"];
      $Identificacion =  $aux+1;

      $insertarDatos= "INSERT INTO datos (Nombres, Primerapellido, Segundoapellido, Genero, Direccion, CorreoElectronico, Telefono, Identificacion) VALUES('$Nombres','$Primerapellido','$Segundoapellido','$Genero','$Direccion','$CorreoElectronico','$Telefono','$Identificacion')";
      $ejecutarInsertar= mysqli_query($enlace, $insertarDatos);

      if(!$insertarDatos){
        echo "error en insertar";
      } 
      echo "Tu ID es $Identificacion";
    }
       
  ?> 