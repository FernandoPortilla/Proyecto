//(funcion)(){
    var formulario = document.getElementById('formulario'),
		Nombres = formulario.Nombres,
        Primerapellido = formulario.Primerapellido,
        Segundoapellido = formulario.Segundoapellido,
		Genero = formulario.Genero,
        Direccion = formulario.Direccion,
        CorreoElectronico = formulario.CorreoElectronico,
        Telefono = formulario.Telefono,
		terminos = formulario.terminos,
		error = document.getElementById('error');
function validarNombre(e){
    if(Nombres.value == '' || Nombres == null){
        console.log('Completa el nombre');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa Un Nombre</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}

function validarApellido1(e){
    if(Primerapellido.value == '' || Primerapellido == null){
        console.log('Completa el primer apellido');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa el Primer Apellido</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}

function validarApellido2(e){
    if(Segundoapellido.value == '' || Segundoapellido == null){
        console.log('Completa el segundo apellido');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa el Segundo Apellido</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}

function validarCorreo(e){
     if(CorreoElectronico.value == '' || CorreoElectronico == null){
        console.log('Completa el correo');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa Un Email</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}
function validarGenero(e){
    if(Genero.value == '' || Genero.value == null){
        console.log('Selecciona Un Sexo');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Selecciona Un Sexo</li>';
        e.preventDefault();
    }else{
    error.style.display='none';
}
}

function validarDireccion(e){
    if(Direccion.value == '' || Direccion == null){
        console.log('Completa la Direccion');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa una Direccion</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}

function validarTelefono(e){
    if(Telefono.value == '' || Telefono == null){
        console.log('Completa el Telefono');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Ingresa el Telefono</li>';
        e.preventDefault();
}else{
    error.style.display='none';
}
}
function validarTerminos(e){
    if(terminos.checked == false){
        console.log('Acepta Los Terminos');
        error.style.display = 'block';
        error.innerHTML = error.innerHTML + '<li>Acepta Los Terminos</li>';
        e.preventDefault();
    }else if(Nombres.value == '' || Nombres == null || CorreoElectronico.value == '' || CorreoElectronico == null || Genero.value == '' || Genero.value == null || Primerapellido.value == '' ||  Primerapellido == null || Segundoapellido.value == '' ||  Segundoapellido == null || Direccion.value == '' ||  Direccion == null || Telefono.value == '' ||  Telefono == null){
    error.style.display='block';
}
}

function validarForm(e){
   error.innerHTML = '';
   error.style.display = 'block';
   validarNombres(e);
   validarApellido1(e);
   validarApellido2(e);
   validarGenero(e);
   validarDireccion(e);
   validarCorreoElectronico(e);
   validarTelefono(e);
   validarTerminos(e);
}


formulario.addEventListener('submit', validarForm);

//}())