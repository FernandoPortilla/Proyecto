<?php
  $servidor="localhost";
  $usuario="root";
  $clave="";
  $baseDeDatos="formulario";

  $enlace = mysqli_connect($servidor, $usuario, $clave, $baseDeDatos);
  $consulta = "SELECT * FROM datos";
            $ejecutarConsulta = mysqli_query($enlace, $consulta);

  if(!$enlace){
    echo"Error en la conexion con el servidor";
  }
	$Identificacion = mysqli_num_rows($ejecutarConsulta);
?>

<html>
<head>
	</head>
<body background="img/fondo.jpg">
	<h1>Tus datos han sido guardados correctamente</h1><br>
	<h2>Tu ID es <?php echo "$Identificacion"; ?> </h2>
	<h3><a href="index.html">Pusla aqui para regresar</a> </h3>
	</body>
</html>