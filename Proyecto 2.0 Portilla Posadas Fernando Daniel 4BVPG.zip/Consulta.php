<?php
  $servidor="localhost";
  $usuario="root";
  $clave="";
  $baseDeDatos="formulario";

  $enlace = mysqli_connect($servidor, $usuario, $clave, $baseDeDatos);

  if(!$enlace){
    echo"Error en la conexion con el servidor";
  }
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <title>Gestión Escolar-Inicio</title>
    <style>
        .container {
            display: grid;
            grid-template-columns: 1fr 3fr;
            grid-gap: 20px;
        }
        header,
        footer {
            color: white;
            border-radius: 20px;
            padding: 30px;
            background-color:#373232;
        }

        aside {
            border-right: 1px solid #999;
        }
    </style>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  </head>
  <body background="img/fondo.jpg">
    <nav class="navbar navbar-dark bg-dark">
      <ul class="nav nav-pills nav-fill mr-auto">
        <li class="nav-item">
          <a class="nav-link " href="index.html">Pagina Principal</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Cuenta
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="Ingresardatos.php">Ingresar</a>
            <a class="dropdown-item" href="Verdatos.php">Modificar</a>
            <a class="dropdown-item" href="Consulta.php">Consulta</a>
          </div>
        </li>
        
        <li class="nav-item">
          <a class="nav-link " href="Contacto.html">Contacto</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="Informacion.html">Información</a>
        </li>
      </ul>
    </nav>
<br>

    <div class="container">
    <form action=""  class="ID" id="ID" name="ID" method="POST">
    <p>Ingresa un numero de identificación para consultar sus datos </p>
    <input required type="text" name="Identificacion" placeholder="ID">
    <input  type="submit" name="Enviar" value="Consultar">
    </form>
     <div class="tabla">
      <table width="100%" align="center" border="#373232" bordercolor="white" bgcolor="gray">
        <tr>
          <th>ID</th>
          <th>Nombre</th>
          <th>Primer apellido</th>
          <th>Segundo apellido</th>
          <th>Genero</th>
          <th>Dirección</th>
          <th>Correo</th>
          <th>Teléfono</th>
        </tr>
    <?php
             if(isset($_POST['Enviar'])){
            $aux = $_POST["Identificacion"];
            $consulta = "SELECT * FROM datos ";
            $ejecutarConsulta = mysqli_query($enlace, $consulta);
            $verFilas = mysqli_num_rows($ejecutarConsulta);
            $fila = mysqli_fetch_array($ejecutarConsulta);
            

            if(!$ejecutarConsulta){
              echo"Error en la consulta";
            }else{
              if($verFilas<1){
                echo"<tr><td>Sin registros</td></tr>";
              }else{
                for($i=0; $i<=$aux; $i++){
                  if ($i==($aux-1)) {
                     echo'
                    <tr>
                      <td>'.$fila[7].'</td>
                      <td>'.$fila[0].'</td>
                      <td>'.$fila[1].'</td>
                      <td>'.$fila[2].'</td>
                      <td>'.$fila[3].'</td>
                      <td>'.$fila[4].'</td>
                      <td>'.$fila[5].'</td>
                      <td>'.$fila[6].'</td>
                    </tr>
                  ';
                    }  
                  
                  $fila = mysqli_fetch_array($ejecutarConsulta);

                }

              }
            }
        }

          ?>
            
            
        
        
      </table>
    </div>


    </div>

</body>

</html>