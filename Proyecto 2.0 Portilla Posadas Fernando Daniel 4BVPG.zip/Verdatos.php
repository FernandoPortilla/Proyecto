<?php
  $servidor="localhost";
  $usuario="root";
  $clave="";
  $baseDeDatos="formulario";

  $enlace = mysqli_connect($servidor, $usuario, $clave, $baseDeDatos);

  if(!$enlace){
    echo"Error en la conexion con el servidor";
  }
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <title>Gestión Escolar-Ver</title>
    <style>
        .container {
            display: grid;
            grid-template-columns: 1fr 3fr;
            grid-gap: 20px;
        }
        header,
        footer {
            color: white;
            border-radius: 20px;
            padding: 30px;
            background-color:#373232;
        }

        aside {
            border-right: 1px solid #999;
        }
    </style>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  </head>
  <body background="img/fondo.jpg">
    <nav class="navbar navbar-dark bg-dark">
      <ul class="nav nav-pills nav-fill mr-auto">
        <li class="nav-item">
          <a class="nav-link " href="index.html">Pagina Principal</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Cuenta
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="Ingresardatos.php">Ingresar</a>
            <a class="dropdown-item" href="Verdatos.php">Modificar</a>
            <a class="dropdown-item" href="Consulta.php">Consulta</a>
          </div>
        </li>
        
        <li class="nav-item">
          <a class="nav-link " href="Contacto.html">Contacto</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="Informacion.html">Información</a>
        </li>
      </ul>
    </nav>
<br>

    <div class="container">
        <div class="botones">
            <form action="" class="Modif" id="Modif" name="Modif" method="POST">
            <input required type="text" name="Identificacion" placeholder="ID">
            <small>Ingresa un numero de identificación para modificar o eliminar</small>
               
                <input  type="submit" name="Eliminar" value="Eliminar">
                
             </form>
             <form action="" class="Modifica" id="Modifica" name="Modifica" method="POST">
                 <div class="Tabla2">
              <table width="60%" align="center" border="#373232" bordercolor="black" bgcolor="gray">
          
          <tr>
            <td><label for="input_nombres"><font font size=5>Nombres</font></label></td>
            <td><input required id="input_nombres" type="text" name="Nombres" value="" placeholder="Nombres" /></td>
          </tr>
          <tr>
            <td><label for="primer_apll"><font  font size=5>Primer apellido</font></label></td>
            <td><input required id="primer_apll" type="text" name="Primerapellido" value="" placeholder="Primer apellido" /></td>
          </tr>
          <tr>
            <td><label for="segundo_apll"><font  font size=5>Segundo apellido</font></label></td>
            <td><input required id="segundo_apll" type="text" name="Segundoapellido" value="" placeholder="Segundo apellido" /></td>
          </tr>
          <tr>
            <td><label for="direccion"><font  font size=5>Dirección</font></label></td>
            <td><input required id="direccion" type="text" name="Direccion" value="" placeholder="Direccion" /></td>
          </tr>
          <tr>
            <td><label for="correo"><font  font size=5>Correo electrónico</font></label></td>
            <td><input required id="correo" type="email" name="CorreoElectronico" value="" placeholder="Correo Electronico" /></td>
          </tr>
          <tr>
            <td><label for="telefono"><font  font size=5>Teléfono</font></label></td>
            <td><input required id="telefono" type="tel" name="Telefono" value="" placeholder="Telefono" /></td>
          </tr>
          <tr>
            <td><label for="input_Genero"><font font size=5>Género</font></label></td>
            <td>
              <div class="Genero">
                <select required name="Genero">
                  <option value="">Seleccione</option>
                  <option value="Hombre">Hombre</option>
                  <option value="Mujer">Mujer</option>
                </select>
              </div>
            </td>
          </tr>
        </table>
        <input align="top" type="submit" name="Modificar" value="Modificar">
    </div>
             </form>
    
        </div>
      <div class="tabla">
      <table width="100%" align="center" border="#373232" bordercolor="white" bgcolor="gray">
        <tr>
          <th>ID</th> 
          <th>Nombre</th>
          <th>Primer apellido</th>
          <th>Segundo apellido</th>
          <th>Genero</th>
          <th>Dirección</th>
          <th>Correo</th>
          <th>Teléfono</th>
        </tr>
    <?php
        if(isset($_POST['Eliminar'])){
           $aux = $_POST["Identificacion"]; 
           $Eli = "DELETE FROM datos WHERE Identificacion=".$aux;
           $Ejecutar = mysqli_query($enlace, $Eli );
        }
        if (isset($_POST['Modificar'])) {
             $aux = $_POST["Identificacion"]; 
                  $Nombres = $_POST["Nombres"];
                  $Primerapellido = $_POST["Primerapellido"];
                  $Segundoapellido = $_POST["Segundoapellido"];
                  $Genero = $_POST["Genero"];
                  $Direccion = $_POST["Direccion"];
                  $CorreoElectronico = $_POST["CorreoElectronico"];
                  $Telefono = $_POST["Telefono"];
            $insertarDatos= "UPDATE datos set Nombres='$Nombres', Primerapellido='$Primerapellido', Segundoapellido='$Segundoapellido',
            Genero='$Genero', Direccion='$Direccion', CorreoElectronico='$CorreoElectronico', Telefono='$Telefono', Identificacion='$aux' WHERE Identificacion=".$aux;
             $ejecutarInsertar= mysqli_query($enlace, $insertarDatos);
        }


            $consulta = "SELECT * FROM datos";
            $ejecutarConsulta = mysqli_query($enlace, $consulta);
            $verFilas = mysqli_num_rows($ejecutarConsulta);
            $fila = mysqli_fetch_array($ejecutarConsulta);

            if(!$ejecutarConsulta){
              echo"Error en la consulta";
            }else{
              if($verFilas<1){
                echo"<tr><td>Sin registros</td></tr>";
              }else{
                for($i=0; $i<=$fila; $i++){
                  echo'
                    <tr>
                      <td>'.$fila[7].'</td>
                      <td>'.$fila[0].'</td>
                      <td>'.$fila[1].'</td>
                      <td>'.$fila[2].'</td>
                      <td>'.$fila[3].'</td>
                      <td>'.$fila[4].'</td>
                      <td>'.$fila[5].'</td>
                      <td>'.$fila[6].'</td>
                    </tr>
                  ';
                  $fila = mysqli_fetch_array($ejecutarConsulta);

                }

              }
            }


          ?>
            
            
        
        
      </table>
    </div>
        
    </div>

</body>

</html>
